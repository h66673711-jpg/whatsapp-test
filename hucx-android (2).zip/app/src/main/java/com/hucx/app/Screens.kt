package com.hucx.app

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

@Composable
fun Root(vm: AppVm) {
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Crossfade(targetState = vm.stage, label = "stage") { stage ->
            when (stage) {
                Stage.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                Stage.Retry -> Form {
                    Text(vm.error ?: "تعذر الاتصال")
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { vm.route() }) { Text("إعادة المحاولة") }
                }
                Stage.Auth -> AuthScreen(vm)
                Stage.Verify -> VerifyScreen(vm)
                Stage.Profile -> ProfileScreen(vm)
                Stage.Home -> Crossfade(targetState = vm.openChat, label = "chat") { c ->
                    if (c == null) HomeScreen(vm) else ChatScreen(vm, c)
                }
            }
        }
    }
}

@Composable
fun Form(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Center,
        content = content
    )
}

@Composable
fun Messages(vm: AppVm) {
    vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(vertical = 8.dp)) }
    vm.notice?.let { Text(it, modifier = Modifier.padding(vertical = 8.dp)) }
}

@Composable
fun Avatar(name: String, size: Dp = 46.dp) {
    val palette = listOf(0xFF2F5BFF, 0xFF00A884, 0xFFE0568A, 0xFFF39C12, 0xFF8E5CF7, 0xFF1AA5C9)
    val c = Color(palette[(name.hashCode() and 0x7fffffff) % palette.size])
    Box(Modifier.size(size).clip(CircleShape).background(c), contentAlignment = Alignment.Center) {
        Text(name.trim().take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.42f).sp)
    }
}

@Composable
fun AuthScreen(vm: AppVm) {
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var register by remember { mutableStateOf(false) }
    Form {
        Text("HUCX", fontSize = 44.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text("سجّل ببريدك الإلكتروني. لا نطلب رقم هاتف.")
        Spacer(Modifier.height(28.dp))
        OutlinedTextField(
            value = email, onValueChange = { email = it }, singleLine = true,
            label = { Text("البريد الإلكتروني") },
            shape = RoundedCornerShape(14.dp),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = pass, onValueChange = { pass = it }, singleLine = true,
            label = { Text("كلمة المرور") },
            shape = RoundedCornerShape(14.dp),
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )
        Messages(vm)
        Button(
            onClick = { vm.authenticate(email.trim(), pass, register) },
            enabled = !vm.busy && email.isNotBlank() && pass.length >= 6,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text(if (register) "إنشاء حساب" else "دخول") }
        TextButton(onClick = { register = !register }) { Text(if (register) "لدي حساب بالفعل" else "إنشاء حساب جديد") }
        if (!register) {
            TextButton(onClick = { vm.resetPassword(email.trim()) }, enabled = !vm.busy) { Text("نسيت كلمة المرور؟") }
        }
    }
}

@Composable
fun VerifyScreen(vm: AppVm) {
    Form {
        Text("تحقق من بريدك", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("أرسلنا رابط تحقق إلى بريدك. افتح الرابط ثم ارجع إلى التطبيق واضغط الزر.")
        Messages(vm)
        Button(onClick = { vm.checkVerified() }, enabled = !vm.busy, modifier = Modifier.fillMaxWidth()) { Text("تحققت من بريدي") }
        TextButton(onClick = { vm.resend() }, enabled = !vm.busy) { Text("إعادة إرسال الرابط") }
        TextButton(onClick = { vm.signOut() }) { Text("تسجيل الخروج") }
    }
}

@Composable
fun ProfileScreen(vm: AppVm) {
    var username by remember { mutableStateOf("") }
    var display by remember { mutableStateOf("") }
    Form {
        Text("أنشئ ملفك", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = username, onValueChange = { username = it }, singleLine = true,
            label = { Text("اسم المستخدم (إنجليزي)") }, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = display, onValueChange = { display = it }, singleLine = true,
            label = { Text("الاسم المعروض") }, modifier = Modifier.fillMaxWidth()
        )
        Messages(vm)
        Button(
            onClick = { vm.createProfile(username, display) },
            enabled = !vm.busy && username.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) { Text("متابعة") }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: AppVm) {
    val chats by remember { Repo.chats() }.collectAsState(initial = emptyList())
    // 0 none, 1 choose, 2 new chat, 3 new group
    var dlg by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf("") }
    var groupTitle by remember { mutableStateOf("") }
    var groupMembers by remember { mutableStateOf("") }
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("المحادثات", fontWeight = FontWeight.Bold)
                        vm.me?.let { Text("@${it.username}", fontSize = 12.sp) }
                    }
                },
                actions = { TextButton(onClick = { vm.signOut() }) { Text("خروج") } }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { dlg = 1 }, shape = CircleShape) { Text("+", fontSize = 28.sp) }
        }
    ) { pad ->
        if (chats.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("ابدأ محادثة أو أنشئ مجموعة بالضغط على +")
            }
        } else {
            LazyColumn(Modifier.padding(pad).fillMaxSize()) {
                items(chats, key = { it.id }) { c ->
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.open(c) }.padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(c.title)
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(c.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            if (c.last.isNotEmpty()) Text(c.last, maxLines = 1, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                        }
                    }
                }
            }
        }
    }
    if (dlg == 1) {
        AlertDialog(
            onDismissRequest = { dlg = 0 },
            title = { Text("جديد") },
            text = {
                Column {
                    TextButton(onClick = { dlg = 2 }) { Text("محادثة جديدة") }
                    TextButton(onClick = { dlg = 3 }) { Text("مجموعة جديدة") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { dlg = 0 }) { Text("إلغاء") } }
        )
    }
    if (dlg == 2) {
        AlertDialog(
            onDismissRequest = { dlg = 0 },
            title = { Text("محادثة جديدة") },
            text = {
                Column {
                    OutlinedTextField(
                        value = name, onValueChange = { name = it }, singleLine = true,
                        label = { Text("اسم المستخدم") }
                    )
                    Messages(vm)
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.startChat(name) { dlg = 0; name = "" } }, enabled = !vm.busy) { Text("ابدأ") }
            },
            dismissButton = { TextButton(onClick = { dlg = 0 }) { Text("إلغاء") } }
        )
    }
    if (dlg == 3) {
        AlertDialog(
            onDismissRequest = { dlg = 0 },
            title = { Text("مجموعة جديدة") },
            text = {
                Column {
                    OutlinedTextField(
                        value = groupTitle, onValueChange = { groupTitle = it }, singleLine = true,
                        label = { Text("اسم المجموعة") }
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = groupMembers, onValueChange = { groupMembers = it },
                        label = { Text("أسماء المستخدمين مفصولة بفاصلة") }
                    )
                    Messages(vm)
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { vm.startGroup(groupTitle, groupMembers) { dlg = 0; groupTitle = ""; groupMembers = "" } },
                    enabled = !vm.busy
                ) { Text("إنشاء") }
            },
            dismissButton = { TextButton(onClick = { dlg = 0 }) { Text("إلغاء") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: AppVm, chat: ChatItem) {
    val msgs by remember(chat.id) { Repo.messages(chat.id) }.collectAsState(initial = emptyList())
    val myId = vm.me?.uid ?: ""
    var text by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var blocked by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.sendImage(chat.id, uri)
    }
    BackHandler { vm.closeChat() }
    LaunchedEffect(msgs) { Repo.markRead(chat.id, msgs) }
    LaunchedEffect(chat.id) {
        if (!chat.isGroup) blocked = try { Repo.isBlocked(chat.otherUid) } catch (e: Exception) { false }
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(chat.title, 36.dp)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(chat.title, fontWeight = FontWeight.Bold)
                            if (chat.isGroup) Text("${chat.memberCount} أعضاء", fontSize = 12.sp)
                        }
                    }
                },
                navigationIcon = { TextButton(onClick = { vm.closeChat() }) { Text("رجوع") } },
                actions = {
                    if (!chat.isGroup) {
                        TextButton(onClick = { menu = true }) { Text("⋮", fontSize = 22.sp) }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("إبلاغ") }, onClick = { menu = false; vm.report(chat.otherUid) })
                            DropdownMenuItem(
                                text = { Text(if (blocked) "إلغاء الحظر" else "حظر") },
                                onClick = { menu = false; vm.toggleBlock(chat.otherUid, blocked) { blocked = !blocked } }
                            )
                        }
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().imePadding()) {
            LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), reverseLayout = true) {
                items(msgs.reversed(), key = { it.id }) { m -> Bubble(m, m.senderId == myId, chat.isGroup) }
            }
            if (vm.uploading) LinearProgressIndicator(Modifier.fillMaxWidth())
            vm.notice?.let { Text(it, modifier = Modifier.padding(horizontal = 12.dp)) }
            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { picker.launch("image/*") }) { Text("📎", fontSize = 22.sp) }
                OutlinedTextField(
                    value = text, onValueChange = { text = it },
                    modifier = Modifier.weight(1f), placeholder = { Text("اكتب رسالة") },
                    shape = RoundedCornerShape(24.dp), maxLines = 4
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    val t = text.trim()
                    if (t.isNotEmpty()) { vm.send(chat.id, t); text = "" }
                }) { Text("إرسال") }
            }
        }
    }
}

@Composable
fun Bubble(m: Msg, mine: Boolean, group: Boolean) {
    Box(
        Modifier.fillMaxWidth().padding(vertical = 3.dp),
        contentAlignment = if (mine) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = if (mine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
            contentColor = if (mine) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
        ) {
            Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                if (group && !mine && m.senderName.isNotEmpty()) {
                    Text(m.senderName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                }
                if (m.imageUrl.isNotEmpty()) {
                    AsyncImage(
                        model = m.imageUrl, contentDescription = "صورة",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.sizeIn(maxWidth = 240.dp, maxHeight = 320.dp).clip(RoundedCornerShape(12.dp))
                    )
                }
                if (m.text.isNotEmpty()) Text(m.text)
                if (mine) Text(
                    if (m.readBy.size > 1) "✓✓" else "✓",
                    fontSize = 11.sp, modifier = Modifier.align(Alignment.End)
                )
            }
        }
    }
}
