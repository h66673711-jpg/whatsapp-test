package com.hucx.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager

class HucxApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel("messages", "الرسائل", NotificationManager.IMPORTANCE_HIGH)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }
}
