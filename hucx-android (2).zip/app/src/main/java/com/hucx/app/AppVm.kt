package com.hucx.app

import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuthException
import kotlinx.coroutines.launch
import kotlin.coroutines.cancellation.CancellationException

enum class Stage { Loading, Retry, Auth, Verify, Profile, Home }

class AppVm : ViewModel() {
    var stage by mutableStateOf(Stage.Loading); private set
    var busy by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set
    var notice by mutableStateOf<String?>(null); private set
    var me by mutableStateOf<Profile?>(null); private set
    var openChat by mutableStateOf<ChatItem?>(null); private set
    var uploading by mutableStateOf(false); private set

    init { route() }

    fun route() { viewModelScope.launch { resolve() } }

    private suspend fun resolve() {
        val u = Repo.auth.currentUser
        if (u == null) { stage = Stage.Auth; return }
        if (!u.isEmailVerified) { stage = Stage.Verify; return }
        try {
            val p = Repo.loadProfile()
            if (p == null) {
                stage = Stage.Profile
            } else {
                me = p
                stage = Stage.Home
                try { Repo.saveToken() } catch (_: Exception) { }
            }
        } catch (e: Exception) {
            error = "تعذر الاتصال بالخادم"
            stage = Stage.Retry
        }
    }

    private fun run(block: suspend () -> Unit) {
        viewModelScope.launch {
            busy = true; error = null; notice = null
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = friendly(e)
            } finally {
                busy = false
            }
        }
    }

    private fun friendly(e: Exception): String = when (e) {
        is FirebaseAuthException -> when (e.errorCode) {
            "ERROR_EMAIL_ALREADY_IN_USE" -> "هذا البريد مسجل مسبقًا"
            "ERROR_WEAK_PASSWORD" -> "كلمة المرور ضعيفة (6 أحرف على الأقل)"
            "ERROR_INVALID_EMAIL" -> "البريد الإلكتروني غير صالح"
            "ERROR_USER_NOT_FOUND", "ERROR_WRONG_PASSWORD", "ERROR_INVALID_CREDENTIAL" -> "البريد أو كلمة المرور غير صحيحة"
            else -> "تعذر تنفيذ الطلب (${e.errorCode})"
        }
        is IllegalArgumentException, is IllegalStateException -> e.message ?: "حدث خطأ"
        else -> "حدث خطأ. تحقق من الاتصال وحاول مجددًا"
    }

    fun authenticate(email: String, pass: String, register: Boolean) = run {
        if (register) Repo.register(email, pass) else Repo.login(email, pass)
        resolve()
    }

    fun checkVerified() = run {
        if (Repo.refreshVerified()) resolve() else error = "لم يتم التحقق بعد. افتح الرابط في بريدك ثم أعد المحاولة"
    }

    fun resetPassword(email: String) = run {
        require(email.isNotBlank()) { "أدخل بريدك الإلكتروني أولًا" }
        Repo.sendPasswordReset(email)
        notice = "إن كان البريد مسجلًا، سيصلك رابط استعادة كلمة المرور"
    }

    fun resend() = run { Repo.resendVerification(); notice = "أرسلنا رابط التحقق مرة أخرى" }

    fun createProfile(username: String, display: String) = run {
        me = Repo.createProfile(username, display)
        stage = Stage.Home
        try { Repo.saveToken() } catch (_: Exception) { }
    }

    fun startChat(username: String, done: () -> Unit) = run {
        val mine = me ?: return@run
        val p = Repo.findUser(username) ?: throw IllegalStateException("لا يوجد مستخدم بهذا الاسم")
        if (p.uid == mine.uid) throw IllegalStateException("هذا حسابك أنت")
        openChat = Repo.openChat(mine, p)
        done()
    }

    fun startGroup(title: String, members: String, done: () -> Unit) = run {
        val mine = me ?: return@run
        openChat = Repo.createGroup(mine, title, members.split(",", "،", " ", "\n"))
        done()
    }

    fun sendImage(chatId: String, uri: Uri) {
        viewModelScope.launch {
            uploading = true
            try { Repo.sendImage(chatId, uri, me?.displayName ?: "") } catch (e: Exception) { notice = "تعذر إرسال الصورة" } finally { uploading = false }
        }
    }

    fun toggleBlock(target: String, currently: Boolean, done: () -> Unit) = run {
        Repo.setBlocked(target, !currently)
        notice = if (!currently) "تم حظر المستخدم" else "تم إلغاء الحظر"
        done()
    }

    fun open(c: ChatItem) { notice = null; openChat = c }
    fun closeChat() { notice = null; openChat = null }

    fun send(chatId: String, text: String) {
        viewModelScope.launch {
            try { Repo.send(chatId, text, me?.displayName ?: "") } catch (e: Exception) { notice = "تعذر إرسال الرسالة. قد تكون محظورًا أو غير متصل" }
        }
    }

    fun report(target: String) = run { Repo.report(target); notice = "تم إرسال البلاغ" }

    fun signOut() {
        Repo.auth.signOut()
        me = null; openChat = null; error = null; notice = null
        stage = Stage.Auth
    }
}
