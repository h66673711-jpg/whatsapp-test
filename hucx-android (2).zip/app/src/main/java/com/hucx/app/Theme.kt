package com.hucx.app

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF2F5BFF), onPrimary = Color.White,
    secondary = Color(0xFF00A884),
    background = Color(0xFFF3F6FB), surface = Color(0xFFF3F6FB),
    surfaceVariant = Color(0xFFE2E8F4), onSurfaceVariant = Color(0xFF0F1B33),
    onBackground = Color(0xFF0F1B33), onSurface = Color(0xFF0F1B33)
)
private val DarkColors = darkColorScheme(
    primary = Color(0xFF6F8DFF), onPrimary = Color(0xFF0D1424),
    secondary = Color(0xFF2ED3A8),
    background = Color(0xFF0D1424), surface = Color(0xFF0D1424),
    surfaceVariant = Color(0xFF1D2B52), onSurfaceVariant = Color(0xFFEAF0FF),
    onBackground = Color(0xFFEAF0FF), onSurface = Color(0xFFEAF0FF)
)

@Composable
fun HucxTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors, content = content)
}
