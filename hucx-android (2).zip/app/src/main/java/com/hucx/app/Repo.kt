package com.hucx.app

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageMetadata
import android.net.Uri
import java.util.UUID
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

data class Profile(val uid: String, val username: String, val displayName: String)
data class ChatItem(val id: String, val otherUid: String, val title: String, val last: String, val lastAt: Long, val isGroup: Boolean = false, val memberCount: Int = 2)
data class Msg(val id: String, val senderId: String, val senderName: String, val text: String, val imageUrl: String, val readBy: List<String>, val at: Long)

object Repo {
    val auth: FirebaseAuth get() = FirebaseAuth.getInstance()
    private val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()
    val uid: String? get() = auth.currentUser?.uid

    suspend fun register(email: String, pass: String) {
        auth.createUserWithEmailAndPassword(email, pass).await()
        auth.currentUser?.sendEmailVerification()?.await()
    }

    suspend fun login(email: String, pass: String) {
        auth.signInWithEmailAndPassword(email, pass).await()
    }

    suspend fun resendVerification() {
        auth.currentUser?.sendEmailVerification()?.await()
    }

    suspend fun sendPasswordReset(email: String) {
        auth.sendPasswordResetEmail(email).await()
    }

    /** Reloads the user and refreshes the token so Firestore rules see email_verified = true. */
    suspend fun refreshVerified(): Boolean {
        val u = auth.currentUser ?: return false
        u.reload().await()
        u.getIdToken(true).await()
        return u.isEmailVerified
    }

    suspend fun loadProfile(): Profile? {
        val id = uid ?: return null
        val s = db.collection("users").document(id).get().await()
        if (!s.exists()) return null
        return Profile(id, s.getString("username") ?: "", s.getString("displayName") ?: "")
    }

    suspend fun createProfile(username: String, display: String): Profile {
        val id = uid ?: error("لا يوجد مستخدم مسجل")
        val lower = username.trim().lowercase()
        require(Regex("^[a-z0-9_]{3,20}$").matches(lower)) {
            "اسم المستخدم: من 3 إلى 20 حرفًا إنجليزيًا صغيرًا أو أرقامًا أو _"
        }
        val name = display.trim().ifEmpty { lower }
        val b = db.batch()
        b.set(db.collection("usernames").document(lower), mapOf("uid" to id))
        b.set(
            db.collection("users").document(id),
            mapOf("username" to lower, "displayName" to name, "status" to "active",
                "createdAt" to FieldValue.serverTimestamp())
        )
        try {
            b.commit().await()
        } catch (e: FirebaseFirestoreException) {
            if (e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED)
                throw IllegalStateException("اسم المستخدم محجوز، اختر اسمًا آخر")
            throw e
        }
        return Profile(id, lower, name)
    }

    suspend fun saveToken() {
        val id = uid ?: return
        val t = FirebaseMessaging.getInstance().token.await()
        db.collection("users").document(id).set(mapOf("fcmToken" to t), SetOptions.merge()).await()
    }

    suspend fun findUser(input: String): Profile? {
        val lower = input.trim().lowercase().removePrefix("@")
        if (lower.isEmpty()) return null
        val u = db.collection("usernames").document(lower).get().await()
        val id = u.getString("uid") ?: return null
        val s = db.collection("users").document(id).get().await()
        return Profile(id, s.getString("username") ?: lower, s.getString("displayName") ?: lower)
    }

    suspend fun openChat(me: Profile, other: Profile): ChatItem {
        val id = listOf(me.uid, other.uid).sorted().joinToString("_")
        db.collection("chats").document(id).set(
            mapOf(
                "type" to "direct",
                "members" to listOf(me.uid, other.uid),
                "names" to mapOf(me.uid to me.displayName, other.uid to other.displayName)
            ),
            SetOptions.merge()
        ).await()
        return ChatItem(id, other.uid, other.displayName, "", 0L)
    }

    fun chats(): Flow<List<ChatItem>> = callbackFlow {
        val me = uid
        if (me == null) {
            trySend(emptyList())
            awaitClose { }
        } else {
            val reg = db.collection("chats").whereArrayContains("members", me)
                .addSnapshotListener { snap, _ ->
                    val list = snap?.documents?.mapNotNull { d ->
                        val members = (d.get("members") as? List<*>)?.filterIsInstance<String>()
                            ?: return@mapNotNull null
                        val isGroup = d.getString("type") == "group"
                        val other = if (isGroup) "" else (members.firstOrNull { it != me } ?: return@mapNotNull null)
                        val names = d.get("names") as? Map<*, *>
                        ChatItem(d.id, other, if (isGroup) (d.getString("title") ?: "مجموعة") else (names?.get(other) as? String ?: "؟"),
                            d.getString("lastMessage") ?: "", d.getTimestamp("lastAt")?.seconds ?: 0L, isGroup, members.size)
                    }?.sortedByDescending { it.lastAt } ?: emptyList()
                    trySend(list)
                }
            awaitClose { reg.remove() }
        }
    }

    fun messages(chatId: String): Flow<List<Msg>> = callbackFlow {
        val reg = db.collection("chats").document(chatId).collection("messages").orderBy("createdAt")
            .addSnapshotListener { snap, _ ->
                val list = snap?.documents?.map { d ->
                    Msg(d.id, d.getString("senderId") ?: "", d.getString("senderName") ?: "", d.getString("text") ?: "", d.getString("imageUrl") ?: "",
                        (d.get("readBy") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
                        d.getTimestamp("createdAt")?.seconds ?: 0L)
                } ?: emptyList()
                trySend(list)
            }
        awaitClose { reg.remove() }
    }

    suspend fun send(chatId: String, text: String, myName: String) {
        val me = uid ?: return
        val chat = db.collection("chats").document(chatId)
        chat.collection("messages").add(
            mapOf(
                "senderId" to me, "senderName" to myName, "text" to text,
                "createdAt" to FieldValue.serverTimestamp(),
                "readBy" to listOf(me), "deliveredTo" to listOf(me)
            )
        ).await()
        chat.update(mapOf("lastMessage" to text.take(80), "lastAt" to FieldValue.serverTimestamp())).await()
    }

    suspend fun markRead(chatId: String, msgs: List<Msg>) {
        val me = uid ?: return
        for (m in msgs) {
            if (m.senderId != me && me !in m.readBy) {
                try {
                    db.collection("chats").document(chatId).collection("messages").document(m.id)
                        .update("readBy", FieldValue.arrayUnion(me)).await()
                } catch (_: Exception) {
                }
            }
        }
    }

    suspend fun createGroup(me: Profile, title: String, usernames: List<String>): ChatItem {
        val name = title.trim()
        require(name.isNotEmpty()) { "اكتب اسم المجموعة" }
        val others = usernames.map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        require(others.isNotEmpty()) { "أضف عضوًا واحدًا على الأقل" }
        val profiles = others.map { findUser(it) ?: throw IllegalStateException("لا يوجد مستخدم باسم $it") }
        val members = (listOf(me.uid) + profiles.map { it.uid }).distinct()
        require(members.size in 2..256) { "عدد الأعضاء غير صالح" }
        val ref = db.collection("chats").document()
        ref.set(
            mapOf(
                "type" to "group", "title" to name, "members" to members,
                "admins" to listOf(me.uid), "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()
        return ChatItem(ref.id, "", name, "", 0L, true, members.size)
    }

    suspend fun sendImage(chatId: String, uri: Uri, myName: String) {
        val me = uid ?: return
        val ref = FirebaseStorage.getInstance().reference.child("chats/$chatId/${UUID.randomUUID()}.jpg")
        ref.putFile(uri, StorageMetadata.Builder().setContentType("image/jpeg").build()).await()
        val url = ref.downloadUrl.await().toString()
        val chat = db.collection("chats").document(chatId)
        chat.collection("messages").add(
            mapOf(
                "senderId" to me, "senderName" to myName, "text" to "", "imageUrl" to url,
                "createdAt" to FieldValue.serverTimestamp(),
                "readBy" to listOf(me), "deliveredTo" to listOf(me)
            )
        ).await()
        chat.update(mapOf("lastMessage" to "📷 صورة", "lastAt" to FieldValue.serverTimestamp())).await()
    }

    suspend fun isBlocked(target: String): Boolean {
        val me = uid ?: return false
        return db.collection("users").document(me).collection("blocked").document(target).get().await().exists()
    }

    suspend fun setBlocked(target: String, block: Boolean) {
        val me = uid ?: return
        val d = db.collection("users").document(me).collection("blocked").document(target)
        if (block) d.set(mapOf("at" to FieldValue.serverTimestamp())).await() else d.delete().await()
    }

    suspend fun report(target: String) {
        val me = uid ?: return
        db.collection("reports").add(
            mapOf("reporterId" to me, "targetUid" to target, "createdAt" to FieldValue.serverTimestamp())
        ).await()
    }
}
