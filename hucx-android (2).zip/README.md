# HUCX — مشروع Android (Kotlin + Compose + Firebase)

applicationId: `com.hucx.app`

## ما يعمل في هذا الإصدار
تسجيل بالبريد وكلمة المرور مع رابط تحقق واستعادة كلمة المرور، اسم مستخدم فريد، محادثات فردية، علامات ✓ / ✓✓، إشعارات FCM، إبلاغ عن مستخدم.
إضافات هذا الإصدار: مجموعات، إرسال الصور (Firebase Storage)، حظر وإلغاء حظر، شاشة بداية، تصميم محسّن.
## غير موجود بعد
رسائل صوتية، مكالمات، حالات 24 ساعة، قنوات، لوحة إدارة، واجهة إنجليزية، إضافة أعضاء أو مغادرة مجموعة، رمز OTP حقيقي (نستخدم رابط التحقق من Firebase).

## ملاحظة Firebase Storage
إرسال الصور يتطلب تفعيل Storage وخطة Blaze، ومنح الصلاحية عند نشر storage.rules من الـ Console.

## الأسرار (Settings > Secrets and variables > Actions)
| الاسم | الاستخدام |
|---|---|
| GOOGLE_SERVICES_JSON | نص ملف google-services.json كاملًا (مطلوب، أو ضع الملف في app/) |
| KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_PASSWORD, KEY_ALIAS | توقيع Release صالح لـ Google Play (اختياري الآن) |
| FIREBASE_SERVICE_ACCOUNT, FIREBASE_PROJECT_ID | نشر القواعد والدوال (اختياري) |

بدون keystore: يُوقَّع الـ APK بمفتاح debug (يثبّت على الهاتف، لكن Google Play يرفضه).

## الدوال (الإشعارات والإبلاغ التلقائي)
تتطلب خطة Blaze. شغّل workflow باسم "Deploy Firebase rules and functions".
